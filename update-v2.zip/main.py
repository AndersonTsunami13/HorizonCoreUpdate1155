print("hello, world! v2 baby")
input(">")