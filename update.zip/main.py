print("hello, world!")
input(">")